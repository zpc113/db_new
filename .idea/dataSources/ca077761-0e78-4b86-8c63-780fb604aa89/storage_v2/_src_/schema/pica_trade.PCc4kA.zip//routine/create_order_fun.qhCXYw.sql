create
    definer = pica@`%` procedure create_order_fun(IN num int) comment '生成假订单'
BEGIN
	DECLARE f_num	int(11) default 0;
	WHILE f_num <= num DO
		set f_num = f_num+1;
		INSERT INTO `pica_trade`.`trade_order` (
		 `id`,
		`parent_id`,
		`status`,
		`user_type`,
		`user_id`,
		`store_id`,
		`prescriber_id`,
		`drug_id`,
		`goods_id`,
		`goods_type`,
		`goods_version`,
		`goods_name`,
		`goods_label`,
		`goods_quantity`,
		`price`,
		`coupon_id`,
		`coupon_fee`,
		`amount`,
		`total_price`,
		`order_source`,
		`order_type`,
		`expire_time`,
		`pay_expire_time`,
		`delete_flag`,
		`create_time`,
		`create_id`,
		`modified_time`,
		`modified_id`,
		`mobile_phone`,
		`express_type`,
		`express_no`,
		`express_name`,
		`express_fee`,
		`order_address_id`,
		`comments`
	)
	VALUES
		(
		CONCAT(UNIX_TIMESTAMP(), 100000000+FLOOR(RAND() * 10000000) ),
			'0',
			'6',
			NULL,
			'1006276045',
			NULL,
			NULL,
			NULL,
			'10040',
			'3',
			'2',
			'全国职称考通用卡',
			'0',
			'1',
			'2',
			'0',
			'0',
			'2',
			'0',
			'0',
			'0',
			'2020-09-10 13:50:25.019',
			'2020-09-10 13:50:25.019',
			'1',
			'2020-09-10 13:35:25.019',
			'999999',
			'2020-09-10 13:50:36.620',
			'0',
			'15606680071',
			NULL,
			NULL,
			NULL,
			NULL,
			NULL,
			NULL
		);
	END WHILE;

END;

