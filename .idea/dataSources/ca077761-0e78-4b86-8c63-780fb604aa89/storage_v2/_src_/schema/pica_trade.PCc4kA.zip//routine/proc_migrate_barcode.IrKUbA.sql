create
    definer = pica_dev@`%` procedure proc_migrate_barcode()
BEGIN
    DECLARE currGoodsId BIGINT(20);
    DECLARE currMedicId BIGINT(20);
    DECLARE currBarcode VARCHAR(50);
    DECLARE prevMedicId BIGINT(20);
    DECLARE lastPKID BIGINT(20);
    DECLARE pkId BIGINT(20);
    DECLARE isBarcodeExists TINYINT(4);
    DECLARE done INT DEFAULT 0;
    DECLARE cur CURSOR FOR (SELECT a.id, a.medication_id, a.bar_code
                            FROM `pica_trade`.`trade_goods` a
                            WHERE a.store_id > 0 AND a.store_id IS NOT NULL AND a.medication_id > 0 AND a.medication_id IS NOT NULL AND a.goods_type = 5
                            ORDER BY medication_id);
	DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = 1;
	-- DROP TABLE IF EXISTS `tmp_barcode`;
    -- CREATE TEMPORARY TABLE tmp_barcode (bar_code VARCHAR(50) NOT NULL);

    -- 初始化数据
	SET prevMedicId = 0;
	DELETE FROM log WHERE id > 0;

    -- 更新药品库 barcode
	OPEN cur;
		FETCH cur INTO currGoodsId, currMedicId, currBarcode;
		WHILE (done <> 1) DO
			SELECT COUNT(*) INTO isBarcodeExists FROM `pica_trade`.`trade_medication_lib` WHERE bar_code = currBarcode LIMIT 1;
			-- INSERT INTO proc_log(log) VALUES(CONCAT('begin -> currGoodsId:', currGoodsId, ' | prevMedicId:', prevMedicId, ' | currMedicId:', currMedicId, ' | currBarcode:', currBarcode, ' | isBarcodeExists:', isBarcodeExists));

			-- bar_code 不存在则 根据prevMedicId 判断是否更新过barcode
			IF isBarcodeExists = 0 THEN
			    --  currMedicId是排过序的，当 prevMedicId <> currMedicId 是一个新的药品ID，此时更新
			    IF prevMedicId <> currMedicId THEN
			        IF locate('TMP', currBarcode) = 1 THEN
                        UPDATE `pica_trade`.`trade_medication_lib` SET bar_code = CONCAT('TMP', currMedicId), modified_time = NOW()  WHERE id = currMedicId;
                        UPDATE `pica_trade`.`trade_goods` SET bar_code = CONCAT('TMP', currMedicId), modified_time = NOW() WHERE id = currGoodsId;
                        INSERT INTO log(log) VALUES(CONCAT('1 -> currGoodsId:', currGoodsId, ' | prevMedicId:', prevMedicId, ' | currMedicId:', currMedicId, ' | currBarcode:', currBarcode, ' | isBarcodeExists:', isBarcodeExists));
                    ELSE
                        UPDATE `pica_trade`.`trade_medication_lib` SET bar_code = currBarcode WHERE id = currMedicId;
                        INSERT INTO log(log) VALUES(CONCAT('2 -> currGoodsId:', currGoodsId, ' | prevMedicId:', prevMedicId, ' | currMedicId:', currMedicId, ' | currBarcode:', currBarcode, ' | isBarcodeExists:', isBarcodeExists));
                    END IF;
			    ELSE
			        INSERT INTO `pica_trade`.`trade_medication_lib`(`goods_name`, `goods_description`, `goods_type`, `medic_common_name`, `medic_goods_name` , `size`,`dosage_id`,`usage`,
			        								  `category_id_level2`,`category_id_level3`,`category_id_level4`,`category_id_level5`,
			        								  `otc`,`approval_number`,`manufacturer`,`department`,`expired_time`,`treat_disease`,`input_type`,
			        								  `delete_flag`,`created_id`,`created_time`,`modified_id`,`modified_time`, `bar_code`)
			        SELECT `goods_name`, `goods_description`, `goods_type`,  `medic_common_name`, `medic_goods_name` , `size`,`dosage_id`,`usage`,
			        				`category_id_level2`,`category_id_level3`,`category_id_level4`,`category_id_level5`,
			        				`otc`,`approval_number`,`manufacturer`,`department`,`expired_time`,`treat_disease`,`input_type`,
			        				`delete_flag`,`created_id`,NOW(),`modified_id`,NOW(), currBarcode
			        FROM `pica_trade`.`trade_medication_lib`
			        WHERE id = currMedicId;

			        SET lastPKID = LAST_INSERT_ID();
                    INSERT INTO log(log) VALUES(CONCAT('3 -> currGoodsId:', currGoodsId, ' | lastPKID:', lastPKID, ' | prevMedicId:', prevMedicId, ' | currMedicId:', currMedicId, ' | currBarcode:', currBarcode, ' | isBarcodeExists:', isBarcodeExists));

                    IF locate('TMP', currBarcode) = 1 THEN
                        UPDATE `pica_trade`.`trade_medication_lib` SET bar_code = CONCAT('TMP', lastPKID), modified_time = NOW()  WHERE id = lastPKID;
                        UPDATE `pica_trade`.`trade_goods` SET medication_id = lastPKID, bar_code = CONCAT('TMP', lastPKID), modified_time = NOW() WHERE id = currGoodsId;
                        INSERT INTO log(log) VALUES(CONCAT('4 -> currGoodsId:', currGoodsId, ' | lastPKID:', lastPKID, ' | prevMedicId:', prevMedicId, ' | currMedicId:', currMedicId, ' | currBarcode:', currBarcode, ' | isBarcodeExists:', isBarcodeExists));
                    END IF;

			        INSERT INTO `pica_trade`.`trade_medication_image`(`medication_id`, `image_url`,`image_type`, `image_name`,`image_sort`, `delete_flag`,`created_id`,`created_time`,`modified_id`,`modified_time`)
			        SELECT lastPKID, `image_url`,`image_type`, `image_name`,`image_sort`, `delete_flag`,`created_id`, NOW(), `modified_id`, NOW()
			        FROM `pica_trade`.`trade_medication_image`
			        WHERE medication_id = currMedicId;
			        INSERT INTO log(log) VALUES(CONCAT('5 -> currGoodsId:', currGoodsId, ' | lastPKID:', lastPKID, ' | prevMedicId:', prevMedicId, ' | currMedicId:', currMedicId, ' | currBarcode:', currBarcode, ' | isBarcodeExists:', isBarcodeExists));
			    END IF;
			END IF;

			SET prevMedicId = currMedicId;
			-- INSERT INTO tmp_barcode(bar_code) VALUES(currBarcode);
			FETCH cur INTO currGoodsId, currMedicId, currBarcode;
		END WHILE;
	CLOSE cur;

	 -- 更新商品的 medication_id
	UPDATE `pica_trade`.`trade_goods` a, `pica_trade`.`trade_medication_lib` b
    SET a.medication_id = b.id
    WHERE a.store_id > 0
        AND a.store_id IS NOT NULL
        AND a.medication_id > 0
        AND a.medication_id IS NOT NULL
        AND a.goods_type = 5
        AND a.bar_code = b.bar_code;

    UPDATE `pica_trade`.`trade_medication_lib` SET bar_code = CONCAT('TMP', id) WHERE bar_code like 'TMP::%';

    INSERT INTO log(log) VALUES(CONCAT('6 -> currGoodsId:', currGoodsId, ' | prevMedicId:', prevMedicId, ' | currMedicId:', currMedicId, ' | currBarcode:', currBarcode, ' | isBarcodeExists:', isBarcodeExists));
    -- DROP TABLE IF EXISTS `tmp_barcode`;
END;

