create
    definer = pica@`%` procedure test_insert_log()
BEGIN 
DECLARE y int DEFAULT 1001;
WHILE y<=2001
DO
insert into sign_in_log  values(null,y,0,1,'2020-03-29 20:00:00',1,1,now(),1,now()); 
SET y=y+1; 
END WHILE ; 
commit; 
END;

