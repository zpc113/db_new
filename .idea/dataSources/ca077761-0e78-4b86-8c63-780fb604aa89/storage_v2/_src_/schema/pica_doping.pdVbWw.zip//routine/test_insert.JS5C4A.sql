create
    definer = pica@`%` procedure test_insert()
BEGIN 
DECLARE y int DEFAULT 1001;
WHILE y<=3000
DO
insert into check_in_remind  values(null,y,1,1,1,now(),1,now()); 
SET y=y+1; 
END WHILE ; 
commit; 
END;

