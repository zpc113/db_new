create
    definer = pica@`%` procedure NewProc()
BEGIN
declare i INT;
set i=1;
while i<100000 do    
  insert into test_pref (group_id,type,from_account,operator_account,random,msg_seq,msg_time,msg_type,msg_content_text,delete_flag,created_id,created_time,modified_id,modified_time)
  values(1000000008,'AVChatRoom','1006276061-1-1','1006276061-1-1',1286882199,i,1592917918+i,'TIMTextElem','性能测试',1,1,'2020-06-23 22:05:03',0,'2020-06-23 22:05:03'); 
set i=i+1;    
end while;


END;

