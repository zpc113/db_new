CREATE
	DEFINER = pica@`%` FUNCTION portal_project_fix_fun() RETURNS LONGTEXT COMMENT '学院报表数据同步'
BEGIN
	DECLARE p_id int(11) DEFAULT	0;
	DECLARE p_pass_type tinyint(4) DEFAULT	0;
	DECLARE p_course_require tinyint(4) DEFAULT	0;
	DECLARE p_doctor_id int(11) DEFAULT	0;
	
	DECLARE p_online_exam_id int(11) DEFAULT	0;
	DECLARE p_end_time datetime;
	DECLARE e_end_time datetime;
	DECLARE p_portal_part_content_progress_id int(11) DEFAULT	0;
	
	DECLARE result LONGTEXT;
	DECLARE done INT DEFAULT FALSE; -- 遍历数据结束标志
	DECLARE done_progress INT DEFAULT FALSE; -- 遍历数据结束标志

	DECLARE cur_project_list CURSOR FOR SELECT id,pass_type FROM pica_campaign.portal_project where delete_flag = 1 and project_status in (4,5);
  DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE; -- 将结束标志绑定到游标
 
  set result = '';
  OPEN cur_project_list; -- 打开游标
	-- 调用函数进行数据迁移
	-- pass_type 通过标准：1所有组件通过2根据平均分设定3根据项目内学习时长控制
-- 	course_require 课程学习时长控制 0：不控制 1：按课程时长配置
	read_loop: LOOP
		FETCH cur_project_list INTO p_id,p_pass_type;
		IF done THEN
			LEAVE read_loop; 
		END IF;

		IF p_pass_type = 2 THEN
				SELECT CONCAT(result,'') into result;
			ELSE
					BEGIN
					DECLARE cur_project_progress_list CURSOR FOR SELECT doctor_id from pica_campaign.portal_project_progress where delete_flag = 1 and project_id = 16 and status = 2;
					DECLARE CONTINUE HANDLER FOR NOT FOUND SET done_progress = TRUE; -- 将结束标志绑定到游标
					OPEN cur_project_progress_list; -- 打开游标
					inner_loop: LOOP
					FETCH cur_project_progress_list INTO p_doctor_id;
						IF done_progress THEN
							LEAVE inner_loop; 
						END IF;
						
						SELECT ppc.id,ppc.content_2 ,ppcp.status_end_time into p_portal_part_content_progress_id,p_online_exam_id,p_end_time
						from pica_campaign.portal_part_content ppc inner join pica_campaign.portal_part_content_progress ppcp 
							on ppc.id = ppcp.portal_part_content_id and ppcp.doctor_id = p_doctor_id and ppcp.delete_flag = 1 and ppcp.status = 1
						where
								ppc.part_id in(
								SELECT pp.id FROM pica_campaign.portal_part pp inner join
										(
										SELECT pt.id FROM pica_campaign.portal_templet pt inner join
										(
										SELECT module_id FROM pica_campaign.portal_component_module_mapping pcmm INNER join pica_campaign.portal_project_relevance_mapping pprm
										on pprm.portal_project_id = p_id and pprm.relevance_type = 1 and pprm.delete_flag =1 and pcmm.component_id = pprm.relevance_id
										where pcmm.delete_flag =1
										) a1 on  pt.module_id = a1.module_id
										where pt.delete_flag = 1
										) a2 on a2.id = pp.templet_id
										where pp.delete_flag = 1
								)
								and ppc.delete_flag = 1 
								and type = 1
								and EXISTS (SELECT * from pica_online_exam.p_online_exam_standard s where s.online_exam_id = ppc.content_2 and s.standard_type in(1,2) and s.is_deleted = 0)
								order by ppcp.status_end_time desc
								limit 0,1;
						
							
						SELECT modified_time into e_end_time from pica_online_exam.p_online_exam_user_result 
						where is_deleted = 0 and user_id = p_doctor_id and online_exam_id = p_online_exam_id and pass_flag = 1
						limit 0,1;
						set result =  CONCAT(result,',',p_id,p_portal_part_content_progress_id,':',p_end_time,'|',e_end_time);
-- 						if e_end_time != null and p_end_time != null and e_end_time < p_end_time then
-- 							set result =  CONCAT(result,',',p_id,p_portal_part_content_progress_id,':',p_end_time,'|',e_end_time);
-- 						end if;
						
						
					END LOOP;
					CLOSE cur_project_progress_list;
				end;
	
			
		END IF;	
	END LOOP;
-- 关闭游标
  CLOSE cur_project_list;
	RETURN result;
END;

