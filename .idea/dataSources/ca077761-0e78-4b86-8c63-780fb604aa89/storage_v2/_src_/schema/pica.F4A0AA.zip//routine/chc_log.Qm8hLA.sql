CREATE
	DEFINER = pica@`%` PROCEDURE chc_log()
BEGIN

DECLARE t_id int(11);
DECLARE t_doctor_id int(11);
	DECLARE done INT DEFAULT FALSE; -- 遍历数据结束标志
	DECLARE cur CURSOR FOR 
			SELECT id,doctor_id FROM t_chc_answer_result WHERE exam_id =2003;
  DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE; -- 将结束标志绑定到游标
  OPEN cur; -- 打开游标
	-- 调用函数进行数据迁移
	read_loop: LOOP
		FETCH cur INTO t_id,t_doctor_id;
		IF done THEN
			LEAVE read_loop; 
		END IF;
		-- 更新同步记录状态
		
		
		
		update t_chc_answer_result
    set 
        correct_no = (SELECT count(1) FROM t_chc_answer_log cl WHERE cl.answer_result_id = t_id and doctor_id = t_doctor_id and cl.type = 1),
        wrong_no = (SELECT count(1) FROM t_chc_answer_log cl WHERE cl.answer_result_id = t_id and doctor_id =t_doctor_id and cl.type in (2,3))
    where id = t_id and doctor_id = t_doctor_id and pass_flag = 10 and exam_id = 2003 ;
		
		
		
	END LOOP;
-- 关闭游标
  CLOSE cur;
end;

