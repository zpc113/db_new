create
    definer = root@`%` procedure fixed_used_limit()
BEGIN
	-- 定义变量
	declare s int DEFAULT 0;
	declare doctor_id_tmp int(11) ;
	declare amount_tmp int(11) ;
    declare avilable_tmp int(11) ;
 
	-- 定义游标，并将sql结果集赋值到游标中
	declare doctor_used_limits_cursor CURSOR FOR  select doctor_id, (used_num - used_details) as amount, avilable_sms_num from (SELECT a.doctor_id,  a.used_num, (select count(amount) from sms_doctor_send_detail b where a.doctor_id = b.doctor_id and delete_flag = 1 and type = 1) as used_details FROM sms_doctor_send a) as c where c.used_num >  c.used_details;

	-- 声明当游标遍历完后将标志变量置成某个值
	declare CONTINUE HANDLER FOR NOT FOUND SET s=1;
	-- 打开游标
	open doctor_used_limits_cursor;
		-- 将游标中的值赋值给变量，注意：变量名不要和返回的列名同名，变量顺序要和sql结果列的顺序一致
		fetch doctor_used_limits_cursor into doctor_id_tmp, amount_tmp, avilable_tmp;
		-- 当s不等于1，也就是未遍历完时，会一直循环
		while s<>1 do
			-- 执行业务逻辑
			INSERT INTO `pica`.`sms_doctor_send_detail_shadow`
			(`doctor_id`,`type`,`amount`,`given_num`,`avilable_sms_num`,`created_day`,`batch_no`,`delete_flag`,`created_id`,`created_time`,`modified_id`,`modified_time`)
			VALUES (doctor_id_tmp,1,amount_tmp,0,avilable_tmp,'2020-01-01','00-0000000000000000000000000000011',1,-11,now(),-11,now());
			-- 将游标中的值再赋值给变量，供下次循环使用
			fetch doctor_used_limits_cursor into doctor_id_tmp, amount_tmp, avilable_tmp;
		-- 当s等于1时表明遍历以完成，退出循环
		end while;
	-- 关闭游标
	close doctor_used_limits_cursor;
END;

