CREATE
	DEFINER = pica@`%` PROCEDURE course_report_log_fun1(IN beginId INT, IN endId INT, OUT result INT) COMMENT '学院报表数据同步'
BEGIN
	DECLARE f_id int(11) DEFAULT	0;
	DECLARE f_courseId int(11) DEFAULT	0;
	DECLARE f_doctorId int(11) DEFAULT	0;
	DECLARE f_num	int(11) default 0;
	DECLARE f_flag int(11);
	DECLARE done INT DEFAULT FALSE; -- 遍历数据结束标志
	DECLARE cur CURSOR FOR SELECT id,doctor_id,course_id FROM course_report_log a 
													WHERE a.id = (
														SELECT max(id) FROM course_report_log b WHERE b.doctor_id	= a.doctor_id and b.course_id = a.course_id
													) and id > beginId and id <= endId ORDER BY id ;
	
  DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE; -- 将结束标志绑定到游标
  OPEN cur; -- 打开游标
	-- 调用函数进行数据迁移
	read_loop: LOOP
		FETCH cur INTO f_id,f_doctorId,f_courseId;
		IF done THEN
			LEAVE read_loop; 
		END IF;
		
		SELECT Count(1) into f_flag
        FROM   p_lecture pl
        WHERE  pl.course_id =  f_courseId
           AND pl.delete_flag = 1
           AND pl.study_rank = 1
           AND pl.status = 2
           AND NOT EXISTS (SELECT 1
                           FROM   p_join_course pjc
                           WHERE  pjc.doctor_id = f_doctorId
                              AND pjc.lecture_id = pl.id
                              AND pjc.lecture_progress >= 0.99
                              AND pjc.delete_flag = 1)
           AND NOT EXISTS (SELECT 1
                           FROM   t_file_view_log tvf
                           WHERE  tvf.doctor_id = f_doctorId
                              AND tvf.lecture_id = pl.id
                              AND tvf.percentage >= 1);
			IF f_flag = 0 THEN
				set f_num = f_num+1;
				UPDATE course_report_log set learn_flag = 2,modified_time = SYSDATE() WHERE id = f_id;
			END IF;	
	END LOOP;
-- 关闭游标
  CLOSE cur;
	-- RETURN f_num;
	set result = f_num;
END;

