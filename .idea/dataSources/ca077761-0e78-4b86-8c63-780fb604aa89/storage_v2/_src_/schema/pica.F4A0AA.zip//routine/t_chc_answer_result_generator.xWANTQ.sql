create
    definer = pica@`%` procedure t_chc_answer_result_generator()
BEGIN
	DECLARE t_id int(11);
	DECLARE done INT DEFAULT FALSE; -- 遍历数据结束标志
	DECLARE cur CURSOR FOR SELECT id FROM pica.p_doctor WHERE name is not null and LENGTH(name)>0 limit 0,120000;
  DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE; -- 将结束标志绑定到游标
  OPEN cur; -- 打开游标
	-- 调用函数进行数据迁移
	read_loop: LOOP
		FETCH cur INTO t_id;
		IF done THEN
			LEAVE read_loop; 
		END IF;
		-- 更新同步记录状态
			-- 插入数据
	INSERT INTO `pica`.`t_chc_answer_result`( `doctor_id`, `exam_id`, `type`, `pass_flag`, `custom_value`, `finish_time`, `correct_no`, `wrong_no`, `start_time`, `end_time`, `delete_flag`, `created_id`, `created_time`, `modified_id`, `modified_time`) 
	VALUES (t_id, 2004, 10, 5, '提交考试', 107299, t_id%5+1, 4-t_id%5, 1531041602374, 1531041709673, 1, 414, '2018-07-08 17:20:02', 414, '2018-07-08 17:21:49');
		
		
	END LOOP;
-- 关闭游标
  CLOSE cur;
END;

