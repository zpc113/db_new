create
    definer = pica@`%` procedure award1()
begin
  declare i int;
  set i=1;
  while(i<=104)do
    INSERT INTO `pica_campaign`.`award_card_log`(`id`, `doctor_id`, `card_type`, `delete_flag`, `created_id`, `created_time`, `modified_id`, `modified_time`) VALUES (null, 1006276152, 2, 1, 1006276152, '2020-11-18 17:46:50', 1006276152, '2020-11-18 17:46:50');
    set i=i+1;
  end while;
end;

