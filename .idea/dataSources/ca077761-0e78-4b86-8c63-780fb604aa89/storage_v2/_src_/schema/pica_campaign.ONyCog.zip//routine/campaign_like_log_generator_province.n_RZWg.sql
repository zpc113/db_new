create
    definer = pica@`%` procedure campaign_like_log_generator_province(IN beginId int, IN endId int, IN businessId int,
                                                                      IN channel int, IN contentId int)
BEGIN
	DECLARE people_id int(11) DEFAULT	100925427;
	DECLARE done INT DEFAULT FALSE; -- 遍历数据结束标志
	DECLARE cur CURSOR FOR SELECT id FROM pica.p_doctor WHERE name is not null and LENGTH(name)>0 and id >= beginId and id < endId and delete_flag =1;
  DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE; -- 将结束标志绑定到游标
  
	OPEN cur; -- 打开游标
	read_loop: LOOP
		FETCH cur INTO people_id;
		IF done THEN
			LEAVE read_loop; 
		END IF;
			-- 插入数据
			INSERT INTO `pica_campaign`.`campaign_like_log`(`channel`, `business_id`, `people_id`, `content_id`, `delete_flag`, `created_id`, `created_time`, `modified_id`, `modified_time`) 
			VALUES (channel, businessId, people_id, contentId, 1, 0, SYSDATE(), 0, SYSDATE());
	END LOOP;
-- 关闭游标
  CLOSE cur;
END;

